#pragma once

#include "GEStrategy.h"

namespace GeneratedStrategies {
int f0(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->page_access_count_min();s->set_accessed(s->num1!=s->num3,frame);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f1(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->num1=s->remainder(s->num2,s->num2)<=s->cache_size;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f2(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num3;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f3(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(s->num1){}else{if(s->num3){}else{}}
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f4(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num3;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f5(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f6(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(s->page_access_count_min()){}else{}
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f7(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f8(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->write(1,s->last_accessed_max(),43);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f9(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num2;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f10(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f11(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f12(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f13(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->added_to_cache_min();
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f14(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(false){}s->set_accessed(s->num2,s->num2);if(s->added_to_cache_max()*frame){}else{}
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f15(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(s->last_accessed_max()>=frame){s->num2=s->cache_size;}
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f16(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f17(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f18(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->write(1,s->read(1,s->get_accessed(s->last_accessed_min())),s->last_accessed_max());
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f19(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f20(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->last_accessed_min();
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f21(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num2;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f22(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f23(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f24(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->write(1,s->page_access_count_min(),s->num2!=s->time);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f25(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->write(2,frame,s->division(0,s->num2)==s->page_request);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f26(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f27(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->last_accessed_min();
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f28(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->page_access_count_min();s->set_accessed(s->page_access_count_max()!=s->num1<s->num1,false);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f29(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f30(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f31(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f32(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->page_access_count_min();
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f33(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f34(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f35(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(s->page_access_count_min()){s->set_accessed(s->num1,0);}s->num1=s->num1;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f36(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f37(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->write(1,s->num1,s->num3);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f38(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->num2=841;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f39(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f40(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num3;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f41(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->write(1,frame,s->num3);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f42(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->write(1,s->get_accessed(frame>true),s->find_max(2));
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f43(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f44(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f45(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->set_accessed(s->page_request<=s->last_accessed_max()!=frame,s->num2);s->num1=s->num2;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f46(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f47(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f48(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f49(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f50(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f51(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f52(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->page_access_count_max()+s->get_accessed(s->num2);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f53(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f54(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f55(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->set_accessed(s->num3,frame);if(1<=s->num2<=s->find_min(1)){}
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f56(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f57(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f58(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->get_accessed(s->num3);frame=s->added_to_cache_max();
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f59(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f60(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f61(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f62(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f63(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f64(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(s->added_to_cache_max()-frame){if(frame<=s->last_accessed_max()){}}s->write(1,s->cache_size,s->read(2,s->num1));
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f65(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f66(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f67(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num1;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f68(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(s->num3-frame){s->set_accessed(s->num2,s->time);}s->set_accessed(s->num3,s->cache_size);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f69(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->num1=frame;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f70(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num2;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f71(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num1;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f72(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f73(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(s->remainder(s->cache_size,s->num3)-frame){}else{}
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f74(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num1;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f75(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f76(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f77(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f78(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->added_to_cache_min();
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f79(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f80(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f81(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f82(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f83(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f84(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->page_access_count_min();
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f85(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f86(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f87(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=frame<=s->num2;frame=s->find_min(2)*s->num3;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f88(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f89(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num3;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f90(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->page_access_count_min();
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f91(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(s->division(s->remainder(s->page_request,frame),s->num2)){}else{}
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f92(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->read(1,s->num2);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f93(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	if(s->num2+frame*s->num2){}
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f94(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->num2=s->last_accessed_min();
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f95(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	s->set_accessed(s->num3,s->num1);
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f96(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f97(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f98(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int f99(GEStrategy* s) {
	int iterations = 0;
	int frame = 0;
	frame=s->num1;
	if (frame < 0 || frame >= s->frame_count) frame = 0;
	return frame;
}
int function(GEStrategy* s) {
  switch(s->strategy_index) {
      case 0: return f0(s);
      case 1: return f1(s);
      case 2: return f2(s);
      case 3: return f3(s);
      case 4: return f4(s);
      case 5: return f5(s);
      case 6: return f6(s);
      case 7: return f7(s);
      case 8: return f8(s);
      case 9: return f9(s);
      case 10: return f10(s);
      case 11: return f11(s);
      case 12: return f12(s);
      case 13: return f13(s);
      case 14: return f14(s);
      case 15: return f15(s);
      case 16: return f16(s);
      case 17: return f17(s);
      case 18: return f18(s);
      case 19: return f19(s);
      case 20: return f20(s);
      case 21: return f21(s);
      case 22: return f22(s);
      case 23: return f23(s);
      case 24: return f24(s);
      case 25: return f25(s);
      case 26: return f26(s);
      case 27: return f27(s);
      case 28: return f28(s);
      case 29: return f29(s);
      case 30: return f30(s);
      case 31: return f31(s);
      case 32: return f32(s);
      case 33: return f33(s);
      case 34: return f34(s);
      case 35: return f35(s);
      case 36: return f36(s);
      case 37: return f37(s);
      case 38: return f38(s);
      case 39: return f39(s);
      case 40: return f40(s);
      case 41: return f41(s);
      case 42: return f42(s);
      case 43: return f43(s);
      case 44: return f44(s);
      case 45: return f45(s);
      case 46: return f46(s);
      case 47: return f47(s);
      case 48: return f48(s);
      case 49: return f49(s);
      case 50: return f50(s);
      case 51: return f51(s);
      case 52: return f52(s);
      case 53: return f53(s);
      case 54: return f54(s);
      case 55: return f55(s);
      case 56: return f56(s);
      case 57: return f57(s);
      case 58: return f58(s);
      case 59: return f59(s);
      case 60: return f60(s);
      case 61: return f61(s);
      case 62: return f62(s);
      case 63: return f63(s);
      case 64: return f64(s);
      case 65: return f65(s);
      case 66: return f66(s);
      case 67: return f67(s);
      case 68: return f68(s);
      case 69: return f69(s);
      case 70: return f70(s);
      case 71: return f71(s);
      case 72: return f72(s);
      case 73: return f73(s);
      case 74: return f74(s);
      case 75: return f75(s);
      case 76: return f76(s);
      case 77: return f77(s);
      case 78: return f78(s);
      case 79: return f79(s);
      case 80: return f80(s);
      case 81: return f81(s);
      case 82: return f82(s);
      case 83: return f83(s);
      case 84: return f84(s);
      case 85: return f85(s);
      case 86: return f86(s);
      case 87: return f87(s);
      case 88: return f88(s);
      case 89: return f89(s);
      case 90: return f90(s);
      case 91: return f91(s);
      case 92: return f92(s);
      case 93: return f93(s);
      case 94: return f94(s);
      case 95: return f95(s);
      case 96: return f96(s);
      case 97: return f97(s);
      case 98: return f98(s);
      case 99: return f99(s);
  }
  return 0;
}
}
